<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('halaqah_registrations', function (Blueprint $table) {
            if (!Schema::hasColumn('halaqah_registrations', 'address')) {
                $table->text('address')->nullable()->after('status');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('halaqah_registrations', function (Blueprint $table) {
            if (Schema::hasColumn('halaqah_registrations', 'address')) {
                $table->dropColumn('address');
            }
        });
    }
};
